Set-PSDebug -Trace 1

mkdir build | Out-Null
Set-Location build

& cmake .. -G "Visual Studio 18 2026" `
    -DBUILD_OR_FAIL=1 `
    -DBUILD_CLIENT=1 -DBUILD_SERVER=1 `
    -DBUILD_MASTER=1 -DBUILD_LAUNCHER=1 `
    -DODAMEX_UPDATE_CVARDOCS=0

Set-Location ..
