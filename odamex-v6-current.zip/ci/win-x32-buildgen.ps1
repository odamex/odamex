Set-PSDebug -Trace 1

mkdir "build-x32" | Out-Null
Set-Location "build-x32"

& cmake .. -G "Visual Studio 18 2026" `
    -A Win32 `
    -DBUILD_OR_FAIL=1 `
    -DBUILD_CLIENT=1 -DBUILD_SERVER=1 `
    -DBUILD_MASTER=1 -DBUILD_LAUNCHER=1 `
    -DODAMEX_UPDATE_CVARDOCS=0

Set-Location ..
