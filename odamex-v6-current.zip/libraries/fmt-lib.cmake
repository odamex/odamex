### fmtlib ###

if(BUILD_CLIENT OR BUILD_SERVER OR BUILD_TESTS)
  message(STATUS "Compiling {fmt}...")

  lib_buildgen(
    LIBRARY fmt
    PARAMS "-DFMT_DOC=OFF"
           "-DFMT_INSTALL=ON"
           "-DFMT_TEST=OFF")
  lib_build(LIBRARY fmt)

  find_package(fmt REQUIRED)
  set_target_properties(fmt::fmt PROPERTIES IMPORTED_GLOBAL TRUE)
endif()
