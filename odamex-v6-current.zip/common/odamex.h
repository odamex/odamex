// Emacs style mode select   -*- C++ -*-
//-----------------------------------------------------------------------------
//
// $Id: 5a0aa14608c8ccdbe8fcacfdcac06114692492fa $
//
// Copyright (C) 1993-1996 by id Software, Inc.
// Copyright (C) 2006-2026 by The Odamex Team.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//     This header must be included first by all Odamex/Odasrv TU's.
//
//-----------------------------------------------------------------------------

#pragma once

#include <stdint.h>

#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include <string>
#include <string_view>
#include <vector>
#include <map>

#include <nonstd/span.hpp>
#include "fmt/format.h"
#include "fmt/printf.h"

#include "doomtype.h"
#include "doomdef.h"
#include "doomstat.h"
#include "doomfunc.h"

using namespace std::string_view_literals;
